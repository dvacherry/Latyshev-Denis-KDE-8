﻿#include <iostream>
#include <fstream>
#include <vector>
#include <Windows.h>
using namespace std;

typedef struct
{
    string station;
    int number;
    int time;
}   TRAIN, * PTRAIN;

int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    vector<TRAIN> v;
    TRAIN t;

    // Ввод
    ifstream ifs("in.txt", ios::in);
    while (ifs)
    {
        ifs >> t.station;
        ifs >> t.number;
        ifs >> t.time;

        v.push_back(t);
    }
    ifs.close();

    string name;
    cout << "enter station: ";
    cin >> name;

    bool c = false;
    for (int i = 0; i < v.size() - 1; ++i)
    {
        if (name == v[i].station)
        {
            cout << "---------------------------------------" << endl;
            cout << "STATION: " << v[i].station << endl;
            cout << "NUMBER: " << v[i].number << endl;
            cout << "TIME: " << v[i].time << endl;
            cout << "---------------------------------------" << endl;
            c = true;
        }
    }
    if (!c)
        cout << "not found!" << endl;
}